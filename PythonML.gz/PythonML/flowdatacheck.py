# flowdatacheck.py
# validation of NN model on refined grid
# David Silvester (c) 22/12/2024

import matplotlib.pyplot as plt
import numpy as np
from typing import List, Any, Tuple, Iterator
import copy
import processdata as wd
Vector = list[float]

#-----------------  neural network stuff
def feed_forward_logistic(beta: List[Vector],
                        gamma: List[Vector],
                        inputs: Vector) -> List[Vector]:
    # feeds the input vector through the neural network
    # returns the outputs of both layers
    outputs: List[Vector] = []
    # input vector has dimension n (number of rows of beta)
    # hidden layer has k neurons (number of columns - 1)
    # that are activated using sigmoid function
    input_h = inputs + [1]    # include constant
    output_h = layer_output(beta,input_h)
    # output layer has dimension m
    outputs.append(output_h.tolist())
    input_f = np.concatenate((output_h,np.array([1])))  # include constant
    output_f = softmax_output(gamma,input_f)
    outputs.append(output_f.tolist())
    return outputs
# outputs = feed_forward_logistic(beta,gamma,inputs)

def logisticV(x: Vector) -> Vector:
    return 1.0 / (1 + np.exp(-x))

def layer_output(weights: Vector, input: Vector) -> Vector:
    # weights includes the bias term, inputs includes a 1
    return logisticV(weights@input)
    
def argmax(xs: list) -> int:
    # returns the index of the largest value
    return max(range(len(xs)), key=lambda i: xs[i])

def softmax_nn(layer):
    (neurons,cons)=layer.shape
    exp=np.exp(layer-layer.max())
    divisor = np.sum(exp,axis=1)
    return [exp/np.outer(divisor,np.ones(cons))]

def softmax_output(weights: Vector, input: Vector) -> Vector:
    # weights includes the bias term, inputs includes a 1
    return softmax(weights@input)

# unpack flow data dataset
def flowdata6(n=51):
   with open('./data/grid6_testresultsX.txt',mode='rt',encoding='utf8') as f:
      viscosity=[]
      perturbation=[]
      sym_label=[]
      it=[]
      ib=[]
      mcount=0
      print(__name__)
      for line in range(n):
         try:
            line1=f.readline()
            (v,p,label,b,t,_)=line1.split(",",5)
            if float(p)<0.01 and 1/float(v)>167:
               viscosity.append(float(v))
               perturbation.append(float(p))
               sym_label.append(int(label))
               ib.append(int(b))
               it.append(int(t))
         except Exception:
            print('irregular spacing in line#',line)
            pass
   return viscosity,perturbation,sym_label,it,ib
# (viscosity,perturbation,sym_label,it,ib)=flowdata6()

# ------ generate boundary test data
def gendata(npts=30):
   np.random.seed(21256)
   re1 = np.random.normal(218,4,npts)
   exp1 = np.random.uniform(-16,-3,npts)
   visc1=1/re1
   pert1=10**exp1
   refdata=np.array([visc1,pert1])
   refdataX=copy.copy(refdata.T)
#  rescale the data
   (means, stds) = wd.scale(refdata.T)
   xdata = wd.rescale(refdata.T)
   return xdata, refdataX

#-----------------  binary classification specific stuff
def member_decode(y: Vector) -> int:
      if y==[0,1]:
         return 0  # not a member
      else:
         return 1  # is a member
          
def test_membership(params,xdata,ydata):
   num_correct = 0
   cdata=np.zeros(len(ydata))
   true_positives = false_positives = true_negatives = false_negatives = 0
   for n in range(0,len(ydata)):
        predicted = argmax(feed_forward_logistic(params[0],params[1],xdata[n])[-1])
        actual = argmax(ydata[n])
        labels = ["out","in"]
        print(n, labels[predicted], labels[actual])
        if predicted == actual:
            num_correct += 1
            cdata[n] = 1
            if predicted ==1:
               true_positives += 1
            else:
               true_negatives += 1
        else:
            if predicted ==1:
               false_positives += 1
            else:
               false_negatives += 1
   print(num_correct, "/", len(ydata))
   pstats = [true_positives,false_positives,true_negatives,false_negatives]
   return cdata, pstats
 
#--------------------- execution stuff
if __name__ == "__main__":
   print('\nflow data neural network validation ...')
   (viscosity,perturbation,yesdata,it,ib)=flowdata6()
   valdata=np.array([np.array(viscosity),np.array(perturbation)])
    #  rescale the data
   (means, stds) = wd.scale(valdata.T)
   xdata = wd.rescale(valdata.T)
   xdata = xdata.tolist()
   #ldata = test_network(params,xdata)
   # encode the membership
   ydata = [member_encode(y) for y in yesdata]
   (cdata,pstats) = test_membership(params,xdata,ydata)
   # show results
   (viscosity,perturbation,yesdata,it,ib)=flowdata6()
   valdata=np.array([np.array(viscosity),np.array(perturbation)])
   valdata=valdata.T
   fig, (ax1,ax4) = plt.subplots(1,2,figsize=(8.6,3.8))
   ax1.scatter(1/valdata[:,0],np.log10(valdata[:,1]),c=yesdata,cmap='cool_r')
   ax1.set_xlabel("Reynolds number")
   ax1.set_xlim([200,240])
   ax1.set_ylabel("logarithm of inlet perturbation")
   ax1.set_title("validation data classification")
   ax4.scatter(1/valdata[:,0],np.log10(valdata[:,1]),c=cdata,cmap='bwr')
   ax4.set_title("correct model predictions")
   ax4.set_xlim([200,240])
   plt.show()
   true_positives  = pstats[0]
   false_positives = pstats[1]
   true_negatives  = pstats[2]
   false_negatives = pstats[3]
   precision = true_positives / (true_positives + false_positives)
   recall = true_positives / (true_positives + false_negatives)
   f1 = 2 * precision * recall/(precision + recall)
   print("classification accuracy statistics ...")
   print("precision {:7.4f} | recall {:7.4f} | F1 score {:7.4f}"
           .format(precision, recall,f1))
