# flowprobsdelta.py
# binary classification of symmetric channel flow using shallow neural network
# David Silvester (c) 05/01/2026
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import numpy as np
import processdata as wd
import shallowNN as nn
import copy

# ------ generate probability of base solution
def genprobs(xdata,params):
   plist=[]
   for n in range(0,len(xdata)):
       pp=nn.feed_forward_logistic(params[0],params[1],xdata[n])[-1]
       plist.append(pp[0])
   return np.array(plist)

# ------ generate boundary probing data
def gendata(means,stds,npts=30):
   np.random.seed(21256)
   re1 = np.random.uniform(160,240,npts)
   exp1 = np.random.uniform(-5.5,-2,npts)
   visc1=1/re1
   pert1=10**exp1
   refdata=np.array([visc1,pert1])
   refdataX=copy.copy(refdata.T)
   #  scale the data to fit the training of the network
   xdata = wd.xscale(refdata.T,means,stds)
   return xdata, refdataX

# ------ generate perturbation probing data
def genpts(exp,means,stds,npts=30):
   re1 = np.linspace(205,220,npts)
   visc1=1/re1
   expv=exp*np.ones(npts)
   pert1=10**expv
   refdata=np.array([visc1,pert1])
   refdataX=copy.copy(refdata.T)
   #  scale the data to fit the training of the network
   xdata = wd.xscale(refdata.T,means,stds)
   return xdata, refdataX


# ------ run probing data through trained network
def test_network(params,xdata):
   num_asym = 0
   ldata=np.ones(len(xdata))
   for n in range(0,len(xdata)):
        predicted = nn.argmax(nn.feed_forward_logistic(params[0],params[1],xdata[n])[-1])
        if predicted == 1:
            num_asym = num_asym+1
            ldata[n] = 0
   print(num_asym, "/", len(xdata))
   return ldata

if __name__ == "__main__":
   # load converged NN parameters
   with open('paramsX.npy', 'rb') as f:
      beta = np.load(f)
      gamma = np.load(f)
      means = np.load(f)
      stds = np.load(f)
   params=[beta,gamma]
   print('\nperturbation probability assessment ...')
   # probability boundary computation
   npts=200000
   (xdata,refdataX) = gendata(means,stds,npts)
   xdata = xdata.tolist()
   pdata = genprobs(xdata,params)
   # cumulative distribution computation
   npts=200
   (rdata1,refdataR1) = genpts(-3.5,means,stds,npts)
   rdata1 = rdata1.tolist()
   cdfdata1 = genprobs(rdata1,params)
   npts=200
   (rdata2,refdataR2) = genpts(-15,means,stds,npts)
   rdata2 = rdata2.tolist()
   cdfdata2 = genprobs(rdata2,params)
   #   fig, (ax1,ax4) = plt.subplots(1,2,figsize=(9.5,3.8))
   
   # multirow plotting
   fig = plt.figure(figsize=(8.8,4.2))
   ax1 = plt.subplot(222)
   ax2 = plt.subplot(224)
   ax3 = plt.subplot(121)
   #
   ax3.scatter(1/refdataX[:,0],np.log10(refdataX[:,1]),2,
               c=pdata,cmap='twilight',edgecolor='none')
   ax3.set_title("predicted bifurcation boundary")
   ax3.set_ylabel("logarithm of inlet perturbation")
   ax3.set_xlabel("Reynolds number")
   #
   ax1.plot(1/refdataR1[:,0],cdfdata1)
   ax1.set_title("perturbation of 1e-3.5")
   ax1.set_ylabel("probability")
   ax1.set_xlabel("Reynolds number")
      # cumulative distribution computation
   ax2.plot(1/refdataR2[:,0],cdfdata2)
   ax2.set_title("perturbation of 1e-15")
   ax2.set_ylabel("probability")
   ax2.set_xlabel("Reynolds number")
   
   plt.tight_layout()
   plt.show()
