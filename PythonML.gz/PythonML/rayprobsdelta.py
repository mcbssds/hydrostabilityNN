# rayprobsdelta.py
# binary classification of Rayleigh-Benard problem using shallow neural network
# David Silvester (c) 30/12/2025
import matplotlib.pyplot as plt
import numpy as np
import processdata as wd
import shallowNN as nn
import copy

# ------ generate probability of base solution
def genprobs(xdata,params):
   plist=[]
   for n in range(0,len(xdata)):
       pp=nn.feed_forward_logistic(params[0],params[1],xdata[n])[-1]
       plist.append(pp[0])
   return np.array(plist)

# ------ generate boundary probing data
def gendata(means,stds,npts=30):
   np.random.seed(21256)
   ra1 = np.random.normal(1520,20,npts)
   exp1 = np.random.uniform(-16,-2,npts)
   pert1=10**exp1
   refdata=np.array([ra1,pert1])
   refdataX=copy.copy(refdata.T)
   #  scale the data to fit the training of the network
   xdata = wd.xscale(refdata.T,means,stds)
   return xdata, refdataX

# ------ generate perturbation probing data
def genpts(exp,means,stds,npts=30):
   ra1 = np.linspace(1490,1540,npts)
   expv=exp*np.ones(npts)
   pert1=10**expv
   refdata=np.array([ra1,pert1])
   refdataX=copy.copy(refdata.T)
   #  scale the data to fit the training of the network
   xdata = wd.xscale(refdata.T,means,stds)
   return xdata, refdataX

# ------ run probing data through trained network
def test_network(params,xdata):
   num_asym = 0
   ldata=np.ones(len(xdata))
   for n in range(0,len(xdata)):
        predicted = nn.argmax(nn.feed_forward_logistic(params[0],params[1],xdata[n])[-1])
        if predicted == 1:
            num_asym = num_asym+1
            ldata[n] = 0
   print(num_asym, "/", len(xdata))
   return ldata

if __name__ == "__main__":
   print('\nperturbation probability assessment ...')
   npts=200000
   (xdata,refdataX) = gendata(means,stds,npts)
   xdata = xdata.tolist()
   pdata = genprobs(xdata,params)
   # cumulative distribution computation
   npts=200
   (rdata1,refdataR1) = genpts(-3.5,means,stds,npts)
   rdata1 = rdata1.tolist()
   cdfdata1 = genprobs(rdata1,params)
   npts=200
   (rdata2,refdataR2) = genpts(-15,means,stds,npts)
   rdata2 = rdata2.tolist()
   cdfdata2 = genprobs(rdata2,params)
   
   # multirow plotting
   fig = plt.figure(figsize=(8.8,4.2))
   ax1 = plt.subplot(222)
   ax2 = plt.subplot(224)
   ax3 = plt.subplot(121)
   #
   ax3.scatter(refdataX[:,0],np.log10(refdataX[:,1]),2,
               c=pdata,marker='.',cmap='twilight',edgecolor='none')
   ax3.set_title("predicted bifurcation boundary")
   ax3.set_ylabel("logarithm of hot wall perturbation")
   ax3.set_xlabel("Rayleigh number")
   #
   ax1.plot(refdataR1[:,0],cdfdata1)
   ax1.set_title("perturbation of 1e-3.5")
   ax1.set_ylabel("probability")
   ax1.set_xlabel("Rayleigh number")
      # cumulative distribution computation
   ax2.plot(refdataR2[:,0],cdfdata2)
   ax2.set_title("perturbation of 1e-15")
   ax2.set_ylabel("probability")
   ax2.set_xlabel("Rayleigh number")
   
   plt.tight_layout()
   plt.show()
