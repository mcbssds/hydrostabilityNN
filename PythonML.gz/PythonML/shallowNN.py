# import shallowNN as nn
# requires numpy, ipywidgets and tqdm packages
# David Silvester (c) 21/12/2024

import numpy as np
import ipywidgets as widgets
from tqdm.notebook import tqdm
from typing import List, Any, Tuple
Vector = list[float]

#----------------  activation stuff
def argmax(xs: list) -> int:
    # returns the index of the largest value
    return max(range(len(xs)), key=lambda i: xs[i])
 
def softmax(x: Vector) -> Vector:
    expx=np.exp(x-x.max())
    divisor = np.sum(expx)
    return expx/divisor

def softmax_nnx(params):
    beta=params[0]
    (bneurons,bcons)=beta.shape
    expbeta=np.exp(beta-beta.max())
    divisorb = np.sum(expbeta,axis=1)
    gamma=params[1]
    (gneurons,gcons)=gamma.shape
    expgamma=np.exp(gamma-gamma.max())
    divisorg = np.sum(expgamma,axis=1)
    return [expbeta/np.outer(divisorb,np.ones(bcons)),
            expgamma/np.outer(divisorg,np.ones(gcons))]

def softmax_nn(layer):
    (neurons,cons)=layer.shape
    exp=np.exp(layer-layer.max())
    divisor = np.sum(exp,axis=1)
    return [exp/np.outer(divisor,np.ones(cons))]

def softmax_output(weights: Vector, input: Vector) -> Vector:
    # weights includes the bias term, inputs includes a 1
    return softmax(weights@input)

def logisticV(x: Vector) -> Vector:
    return 1.0 / (1 + np.exp(-x))

def layer_output(weights: Vector, input: Vector) -> Vector:
    # weights includes the bias term, inputs includes a 1
    return logisticV(weights@input)

#-----------------  neural network stuff
def feed_forward_logistic(beta: List[Vector],
                        gamma: List[Vector],
                        inputs: Vector) -> List[Vector]:
    # feeds the input vector through the neural network
    # returns the outputs of both layers
    outputs: List[Vector] = []
    # input vector has dimension n (number of rows of beta)
    # hidden layer has k neurons (number of columns - 1)
    # that are activated using sigmoid function
    input_h = inputs + [1]    # include constant
    output_h = layer_output(beta,input_h)
    # output layer has dimension m
    outputs.append(output_h.tolist())
    input_f = np.concatenate((output_h,np.array([1])))  # include constant
    output_f = softmax_output(gamma,input_f)
    outputs.append(output_f.tolist())
    return outputs
# outputs = nn.feed_forward_logistic(beta,gamma,inputs)
    
def log_gradients(beta: List[Vector],
                      gamma: List[Vector],
                      inputs: Vector,
                      target: Vector) -> List[List[Vector]]:
    # make a prediction and compute the gradient of the cross
    # entropy loss with respect to the neuron weights
    # forward pass
    (hidden,output) = feed_forward_logistic(beta,gamma,inputs)
    outputv = np.array(output)
    hiddenv = np.array(hidden)
    # gradients with respect to output neuron preactivation outputs
    output_deltas = outputv - target
    # gradients with respect to output neuron weights
    hiddenv_h=np.concatenate((hiddenv,[1]))
    output_grads = np.outer(output_deltas,hiddenv_h)
    # gradients with respect to hidden neuron pre-activation outputs
    # computed with sigmoid activation
    hidden_deltas = hiddenv*(1 - hiddenv) * (gamma[:,0:-1].T@output_deltas)
    # gradients with respect to hidden neuron weights
    input_h = inputs + [1]
    hidden_grads = np.outer(hidden_deltas,input_h)
    return [hidden_grads, output_grads]
# [hidden_grads, output_grads] = log_gradients(beta,gamma,inputs,target)

# optimisation function gradient evaluation at x exact value is y
def log_gradient(x: float, y: float,
                    params: List[List[Vector]]) -> List[List[Vector]]:
    # two parameter matrices: beta (hidden layer) and gamma (output layer)
    [hidden_grads, output_grads] = log_gradients(params[0],params[1],x,y)
    # convert to single vector of parameters
    grads=np.concatenate((hidden_grads.flatten(),output_grads.flatten()))
    return grads
# grads = log_gradient(xvalue,yvalue,params)

# cross-entropy loss error for prediction
def error_logistic(x: float, y: Vector,
                    params: List[List[Vector]]) -> float:
    # two parameter matrices: beta (hidden layer) and gamma (output layer)
    (hidden,output) = feed_forward_logistic(params[0],params[1],x)
    likelihoods=-np.log(np.array(output)+1e-33)*np.array(y)
    return np.sum(likelihoods)
# point_error = error_logistic(xvalue,yvalue,params)

def saxpy(xs: Vector, gradient: Vector, step_size: float) -> Vector:
    # vectorised gradient step
    assert len(xs) == len(gradient)
    return xs+step_size*gradient

def logistic_shallow(params,xdata,ydata,its,learning_rate):
    # unpack params
    (bneurons,bcons)=params[0].shape
    (gneurons,gcons)=params[1].shape
    error=[]
    for epoch in tqdm(range(its)):
       for (x,y) in zip(xdata,ydata):
          grad=np.array(log_gradient(x, y, params))
          paramv=np.concatenate((params[0].flatten(),params[1].flatten()))
          paramv=saxpy(paramv,grad,-learning_rate)
          # pack params into array structure
          beta=paramv[0:bneurons*bcons].reshape(bneurons,bcons)
          gamma=paramv[bneurons*bcons:].reshape(gneurons,gcons)
          params=[beta,gamma]
       # compute logistic error
       ee = [error_logistic(x,y,params) for (x,y) in zip(xdata,ydata)]
       eee =np.sum(np.array(ee))
       error.append(eee)
       print(epoch,eee)
    return error, params, grad
# (error,params,grad) = nn.logistic_shallow(params,xdata,ydata,its,learning_rate)


def logistic_gradient(params,xdata,ydata,its,learning_rate):
    # unpack params
    (bneurons,bcons)=params[0].shape
    (gneurons,gcons)=params[1].shape
    error=[]
    # descent steps
    for epoch in tqdm(range(its)):
       garray=np.array([log_gradient(x, y, params) for (x,y) in zip(xdata,ydata)])
       (npts,nparams)=np.shape(garray)
       #grad=sum(garray)/npts
       # total gradient for neurons in output layer
       gradg=sum(garray[:,bneurons*bcons:])/(gneurons*gcons)
       #print("step number",epoch)
       #print(gradg)
       paramg=params[1].flatten()
       paramg=nn.saxpy(paramg,gradg,-learning_rate)
       # pick random gradient for neurons in hidden layer
       (x,y)= random.choice([(x,y) for (x,y) in zip(xdata,ydata)])
       gradb=np.array(log_gradient(x, y, params))
       paramv=np.concatenate((params[0].flatten(),params[1].flatten()))
       paramb=nn.saxpy(paramv,gradb,-learning_rate)
       # compute error squared
       ee = [error_logistic(x,y,params) for (x,y) in zip(xdata,ydata)]
       eee =np.sum(np.array(ee))
       error.append(eee)
       #print(epoch,eee)
       # pack params into array structure
       beta=paramb[0:bneurons*bcons].reshape(bneurons,bcons)
       #gamma=paramg.reshape(gneurons,gcons)
       gamma=paramb[bneurons*bcons:].reshape(gneurons,gcons)
       params=[beta,gamma]
       grad=[gradb[0:bneurons*bcons],gradg]
    return error, [beta,gamma], gradb  #grad
# (error,params,grad) = logistic_gradient(params,xdata,ydata,its,learning_rate)
