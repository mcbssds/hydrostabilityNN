# flowdataNN
# binary classification using shallow neural network
# David Silvester (c) 05/01/2026

import matplotlib.pyplot as plt
import numpy as np
import processdata as wd
import shallowNN as nn
from typing import List, Any, Tuple, Iterator
Vector = list[float]

#-----------------  problem data
# unpack coarse blind flow data dataset
def flowdataX(n=106):
   with open('./data/channel_flow_labelsX.txt',mode='rt',encoding='utf8') as f:
      viscosity=[]
      perturbation=[]
      sym_label=[]
      it=[]
      ib=[]
      mcount=0
      print(__name__)
      for line in range(n):
         try:
            line1=f.readline()
            (r,p,label,b,t,_)=line1.split(",",5)
            if float(p)<0.0101 and float(r)>159.0:
               viscosity.append(1/float(r))
               perturbation.append(float(p))
               sym_label.append(int(label))
               ib.append(int(b))
               it.append(int(t))
         except Exception:
            print('irregular spacing in line#',line)
            pass
   return viscosity,perturbation,sym_label,it,ib
# (viscosity,perturbation,sym_label,it,ib)=flowdata()

# unpack refined blind flow data dataset
def flowdata(n=1477):
   with open('./data/channel_flow_labels.txt',mode='rt',encoding='utf8') as f:
      viscosity=[]
      perturbation=[]
      sym_label=[]
      it=[]
      ib=[]
      mcount=0
      print(__name__)
      for line in range(n):
         try:
            line1=f.readline()
            (r,p,label,b,t,_)=line1.split(",",5)
            if float(p)<0.0101 and float(r)>159.0:
               viscosity.append(1/float(r))
               perturbation.append(float(p))
               sym_label.append(int(label))
               ib.append(int(b))
               it.append(int(t))
         except Exception:
            print('irregular spacing in line#',line)
            pass
   return viscosity,perturbation,sym_label,it,ib
# (viscosity,perturbation,sym_label,it,ib)=flowdata()

# unpack informed flow data dataset
def flowdata5(n=596):
   with open('./data/grid5_flowresults.txt',mode='rt',encoding='utf8') as f:
      viscosity=[]
      perturbation=[]
      sym_label=[]
      it=[]
      ib=[]
      mcount=0
      print(__name__)
      for line in range(n):
         try:
            line1=f.readline()
            (v,p,label,b,t,_)=line1.split(",",5)
            if float(p)<0.01 and 1/float(v)>167:
               viscosity.append(float(v))
               perturbation.append(float(p))
               sym_label.append(int(label))
               ib.append(int(b))
               it.append(int(t))
         except Exception:
            print('irregular spacing in line#',line)
            pass
   return viscosity,perturbation,sym_label,it,ib
# (viscosity,perturbation,sym_label,it,ib)=flowdata5()


# ------ random initial network
import random
def setup():
   #random.seed(20062024)
   np.random.seed(212421)
   inputs=2
   hideneurons=32
   outputs=2
   varb=2/(inputs + hideneurons)
   varg=2/(outputs + hideneurons)
   # intialise via Xavier
   beta = np.random.normal(0,varb,(hideneurons,inputs+1))
   gamma = np.random.normal(0,varb,(outputs,hideneurons+1))
   # initialise via uniform
   gamma = np.random.uniform(-1,1,(outputs,hideneurons+1))
   params=[beta,gamma]
   return params
# params = setup()

#-----------------  binary classification specific stuff

def member_encode(y: int) -> Vector:
    if y==0:
        return [0, 1]  # not a member
    else:
        return [1, 0]  # is a member
        
def member_decode(y: Vector) -> int:
      if y==[0,1]:
         return 0  # not a member
      else:
         return 1  # is a member
          
def test_membership(params,xdata,ydata):
   num_correct = 0
   cdata=np.zeros(len(ydata))
   true_positives = false_positives = true_negatives = false_negatives = 0
   for n in range(0,len(ydata)):
        predicted = nn.argmax(nn.feed_forward_logistic(params[0],params[1],xdata[n])[-1])
        actual = nn.argmax(ydata[n])
        labels = ["no","yes"]
        print(n, labels[predicted], labels[actual])
        if predicted == actual:
            num_correct += 1
            cdata[n] = 1
            if predicted ==1:
               true_positives += 1
            else:
               true_negatives += 1
        else:
            if predicted ==1:
               false_positives += 1
            else:
               false_negatives += 1
   print(num_correct, "/", len(ydata))
   pstats = [true_positives,false_positives,true_negatives,false_negatives]
   return cdata, pstats
   
#--------------------- execution stuff
from time import time, sleep
if __name__ == "__main__":
   split_ratio = 0 #0.25
   print('\nTraining flow data neural network using cross-entropy loss ...')
   # read the appropriate labelled data file
   (viscosity,perturbation,yesdata,it,ib)=flowdata5() #flowdataX(), flowdata()
   print('\nflow data results ...')
   print('{:} experiments with {} bifurcated flows'.format(len(yesdata),sum(yesdata)))
   refdata=np.array([np.array(viscosity),np.array(perturbation)])
   # rescale the data
   (means, stds) = wd.scale(refdata.T)
   xdata = wd.rescale(refdata.T)
   print("mean Re is {:9.6f} | mean perturbation is {:9.6f}\n".format(1/means[0],means[1]))
   xdata=xdata.tolist()
   # encode the membership
   ydata = [member_encode(y) for y in yesdata]
   # split the data set to assess goodness of fit
   (x_train,x_test,y_train,y_test) = wd.train_test_split(xdata,ydata,split_ratio)
   
   # neural network initialisation
   params0 = setup()
   its=5000 #5000
   learning_rate = 0.15 #0.2
   tic=time()
   (error,params,grad) = nn.logistic_shallow(params0,x_train,y_train,its,learning_rate)
   toc=time()-tic
   print("\ncross-entropy minimisation")
   #print(params)
   print("final gradient vector is ")
   print(grad)
   print("{} iterations, learning rate is {:7.4f}".format(its+1,learning_rate))
   print("Elapsed time is {:6.3f} seconds".format(toc))
   
   # show convergence
   ii=[i for i in range(its+1)]
   fits=int(its/4)
   plt.ion()
   fig, (ax1,ax4) = plt.subplots(1,2,figsize=(8.6,3.8))
   ax1.plot(error,'-b')
   ax1.set_xlabel("iterations")
   ax1.set_ylabel("loss functional")
   ax1.set_title("complete training history")
   ax4.plot(ii[fits+1:],error[fits:],'-b')
   ax4.set_xlabel("iterations")
   ax4.set_ylabel("loss functional")
   ax4.set_title("final training history ")
   plt.show()
   
   # save NN parameters in datafile
   with open('params.npy', 'wb') as f:
       np.save(f, params[0])
       np.save(f, params[1])
       np.save(f, means)
       np.save(f, stds)
   print("converged NN parameters saved in params.npy")
      
   # plot training data results
   (cdata,pstats)=test_membership(params,x_train,y_train)
   x_train = np.array(x_train)
   ref_train = wd.unscale(x_train,means,stds)
   yt=[member_decode(y) for y in y_train]
   fig, (ax1,ax4) = plt.subplots(1,2,figsize=(8.6,3.8))
   ax1.scatter(1/ref_train[:,0],np.log10(ref_train[:,1]),5,
                c=yt,cmap='cool_r',edgecolor='none')
   ax1.set_xlabel("Reynolds number")
   ax1.set_ylabel("logarithm of inlet perturbation")
   ax1.set_title("colour shows flow classification")
   ax4.scatter(1/ref_train[:,0],np.log10(ref_train[:,1]),5,
               c=cdata,cmap='copper',edgecolor='none')
   ax4.set_title("correct model classifications")
   ax4.set_xlabel("Reynolds number")
   plt.show()
   
   if len(x_test) > 0:
     (cdata,pstats) = test_membership(params,x_test,y_test)
     # rescale the test data
     x_test=np.array(x_test)
     ref_test = wd.unscale(x_test,means,stds)
     # plot test data results
     ytest=[member_decode(y) for y in y_test]
     fig, (ax1,ax4) = plt.subplots(1,2,figsize=(8.6,3.8))
     ax1.scatter(1/ref_test[:,0],np.log10(ref_test[:,1]),6,
               c=ytest,cmap='cool_r',edgecolor='none')
     ax1.set_xlabel("Reynolds number")
     ax1.set_ylabel("logarithm of inlet perturbation")
     ax1.set_title("colour shows flow classification")
     ax4.scatter(1/ref_test[:,0],np.log10(ref_test[:,1]),6,
                  c=cdata,cmap='copper',edgecolor='none')
     ax4.set_title("correct model classifications")
     ax4.set_xlabel("Reynolds number")
     plt.show()
     # postprocessing
     true_positives  = pstats[0]
     false_positives = pstats[1]
     true_negatives  = pstats[2]
     false_negatives = pstats[3]
     print("binary confusion matrix  ...")
     print(pstats)
     precision = true_positives / (true_positives + false_positives)
     recall = true_positives / (true_positives + false_negatives)
     f1 = 2 * precision * recall/(precision + recall)
     print("classification accuracy statistics ...")
     print("precision {:7.4f} | recall {:7.4f} | F1 score {:7.4f}"
           .format(precision, recall,f1))
 
     assert precision >= 0.9
     assert recall >= 0.95
   else:
      print('Network trained for all {:} data points\n'.format(len(yesdata)))
