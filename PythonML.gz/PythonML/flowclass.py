# flowclass.py
# binary classification of symmetric channel flow using shallow neural network
# David Silvester (c) 24/12/2024
import matplotlib.pyplot as plt
import numpy as np
import processdata as wd
import shallowNN as nn
import copy

# ------ generate boundary probing data
def gendata(means,stds,npts=30):
   np.random.seed(21256)
   re1 = np.random.normal(218,4,npts)
   exp1 = np.random.uniform(-16,-3,npts)
   visc1=1/re1
   pert1=10**exp1
   refdata=np.array([visc1,pert1])
   refdataX=copy.copy(refdata.T)
   #  scale the data to fit the training of the network
   xdata = wd.xscale(refdata.T,means,stds)
   return xdata, refdataX


# ------ run probing data through trained network
def test_network(params,xdata):
   num_asym = 0
   ldata=np.ones(len(xdata))
   for n in range(0,len(xdata)):
        predicted = nn.argmax(nn.feed_forward_logistic(params[0],params[1],xdata[n])[-1])
        if predicted == 1:
            num_asym = num_asym+1
            ldata[n] = 0
   print(num_asym, "/", len(xdata))
   return ldata

if __name__ == "__main__":
   print('\nbifurcation boundary generation ...')
   npts=200000
   (xdata,refdataX) = gendata(means,stds,npts)
   xdata = xdata.tolist()
   ldata = test_network(params,xdata)
   fig, (ax1,ax4) = plt.subplots(1,2,figsize=(8.6,3.8))
   ax1.scatter(1/ref_train[:,0],np.log10(ref_train[:,1]),5,
               c=yt,cmap='cool_r',edgecolor='none')
   ax1.set_xlabel("Reynolds number")
   ax1.set_ylabel("logarithm of inlet perturbation")
   ax1.set_title("training data classifications")
   ax4.scatter(1/refdataX[:,0],np.log10(refdataX[:,1]),2,
               c=ldata,marker='.',cmap='cool_r',edgecolor='none')
   ax4.set_title("predicted bifurcation boundary")
   ax4.set_xlabel("Reynolds number")
   plt.show()
