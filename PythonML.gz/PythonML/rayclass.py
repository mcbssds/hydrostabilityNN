# rayclass.py
# binary classification of Rayleigh-Benard problem using shallow neural network
# David Silvester (c) 24/12/2024
import matplotlib.pyplot as plt
import numpy as np
import processdata as wd
import shallowNN as nn
import copy

# ------ generate boundary test data
def gendata(means,stds,npts=30):
   np.random.seed(21256)
   ra1 = np.random.normal(1520,20,npts)
   exp1 = np.random.uniform(-16,-3,npts)
   pert1=10**exp1
   refdata=np.array([ra1,pert1])
   refdataX=copy.copy(refdata.T)
   #  scale the data to fit the training of the network
   xdata = wd.xscale(refdata.T,means,stds)
   return xdata, refdataX

# ------ run probing data through trained network
def test_network(params,xdata):
   num_asym = 0
   ldata=np.ones(len(xdata))
   for n in range(0,len(xdata)):
        predicted = nn.argmax(nn.feed_forward_logistic(params[0],params[1],xdata[n])[-1])
        if predicted == 1:
            num_asym = num_asym+1
            ldata[n] = 0
   print(num_asym, "/", len(xdata))
   return ldata

if __name__ == "__main__":
   print('\nbifurcation boundary generation ...')
   npts=200000
   (xdata,refdataX) = gendata(means,stds,npts)
   xdata = xdata.tolist()
   ldata = test_network(params,xdata)
   fig, (ax1,ax4) = plt.subplots(1,2,figsize=(8.6,3.8))
   ax1.scatter(refdata[:,0],np.log10(refdata[:,1]),5,
               c=yesdata,cmap='cool_r',edgecolor='none')
   ax1.set_xlabel("Rayleigh number")
   ax1.set_ylabel("logarithm of hot wall perturbation")
   ax1.set_title("training data classifications")
   ax4.scatter(refdataX[:,0],np.log10(refdataX[:,1]),2,
               c=ldata,marker='.',cmap='cool_r',edgecolor='none')
   ax4.set_title("predicted bifurcation boundary")
   ax4.set_xlabel("Rayleigh number")
   plt.show()
