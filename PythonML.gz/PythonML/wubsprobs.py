# wubprobs.py
# binary classification of Elder problem using shallow neural network
# David Silvester (c) 16/07/2025
import matplotlib.pyplot as plt
import numpy as np
import processdata as wd
import shallowNN as nn
import copy

# ------ generate probability of base solution
def genprobs(xdata,params):
   plist=[]
   for n in range(0,len(xdata)):
       pp=nn.feed_forward_logistic(params[0],params[1],xdata[n])[-1]
       plist.append(pp[0])
   return np.array(plist)

# ------ generate boundary test data sets
def gendata1(means,stds,npts=30):
   np.random.seed(21256)
   ra1 = np.random.normal(2.9e9,2e7,npts)
   pr1 = np.random.uniform(10,1100,npts)
   #pr1 = np.random.normal(1000,200,npts)
   refdata=np.array([ra1,pr1])
   refdata1=copy.copy(refdata.T)
#  scale the data to fit the training of the network
   xdata1 = wd.xscale(refdata.T,means,stds)
   return xdata1, refdata1

def gendata2(means,stds,npts=30):
   np.random.seed(21257)
   ra2 = np.random.normal(2.99e9,3e7,npts)
   pr2 = np.random.normal(160,50,npts)
   refdata=np.array([ra2,pr2])
   refdata2=copy.copy(refdata.T)
   #  scale the data to fit the training of the network
   xdata2 = wd.xscale(refdata.T,means,stds)
   return xdata2, refdata2


# ------ run probing data through trained network
def test_network(params,xdata):
   num_asym = 0
   ldata=np.ones(len(xdata))
   for n in range(0,len(xdata)):
        predicted = nn.argmax(nn.feed_forward_logistic(params[0],params[1],xdata[n])[-1])
        if predicted == 1:
            num_asym = num_asym+1
            ldata[n] = 0
   print(num_asym, "/", len(xdata))
   return ldata

if __name__ == "__main__":
   print('\nbifurcation probability assessment ...')
   pbase = genprobs(xdata,params)
   x_train=np.array(xdata)
   ref_train = wd.unscale(x_train,means,stds)
   fig, (ax1,ax4) = plt.subplots(1,2,figsize=(8.6,3.8))
   ax1.scatter(ref_train[:,0],ref_train[:,1],6,
               c=pbase,cmap='twilight',edgecolor='none')
   ax1.set_xlabel("Rayleigh number")
   ax1.set_ylabel("Prandtl number")
   ax1.set_title("probability of bifurcated solution")
   # boundary computation
   npts=200000
   (xdata1,refdata1) = gendata1(means,stds,npts)
   xdata1 = xdata1.tolist()
   ldata1 = test_network(params,xdata1)
   (xdata2,refdata2) = gendata2(means,stds,npts)
   xdata2 = xdata2.tolist()
   pbase2 = genprobs(xdata2,params)
   ax4.scatter(refdata2[:,0],refdata2[:,1],2,
               c=pbase2,cmap='twilight',edgecolor='none')
   ax4.set_title("zoom of boundary")
   ax4.set_xlabel("Rayleigh number")
   plt.show()
