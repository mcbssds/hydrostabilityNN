# import processdata as wd
# requires numpy and random packages
# David Silvester (c) 24/12/2024

from typing import List, Any, Tuple

# ---------- generic data processing
def mean(xs: List[Any]) -> float:
    return sum(xs) / len(xs)

def sd(xs: List[Any]) -> float:
    xx=sum(np.power(xs,2))
    mm=np.power(mean(xs),2)
    var=(xx-len(xs)*mm)/(len(xs)-1)
    return np.sqrt(var)

def stats(xs: List[Any]):
   num_points = len(xs)
   print("       mean is",mean(xs))
   print("  deviation is",sd(xs))
   return

def covariance(xs: List[int], ys: List[float]) -> float:
    assert len(xs) == len(ys) # list need to have same length
    xmean=mean(xs)
    ymean=mean(ys)
    xdev=[x-xmean for x in xs]
    ydev=[y-ymean for y in ys]
    cov=sum(x_i*y_i for (x_i,y_i) in zip(xdev,ydev))/(len(xs)-1)
    return cov
    
def correlation(xs: List[int], ys: List[float]) -> float:
    stdev_x = sd(xs)
    stdev_y = sd(ys)
    if stdev_x > 0 and stdev_y > 0:
        return covariance(xs, ys) / stdev_x / stdev_y
    else:
        return 0.0    # if no variation, correlation is zero

# ---------- data rescaling using numpy
import numpy as np
Vector = list[float]

def demean(data:List[Vector]) -> List[Vector]:
    mean_data = np.mean(data, axis=0)
    return data-mean_data
# xdata = wd.demean(data)

def scale(data: List[Vector]) -> Tuple[Vector, Vector]:
    # returns the means and standard deviations for feature (column)
    means = np.mean(data, axis=0)
    stds= np.std(data, axis=0, ddof=1)
    return means, stds
# (means, stds) = wd.scale(data)

vectors = [[-3, -1, 1], [-1, 0, 1], [1, 1, 1]]
means, stdevs = scale(vectors)
assert np.all(means == [-1, 0, 1])
assert np.all(stdevs == [2, 1, 0])

def xscale(data: List[Vector],
            means:List[Vector],
            stds:List[Vector]) -> List[Vector]:
    # rescales column data with reference mean and deviation
    data=np.array(data)
    (n,m) = np.shape(data)
    rdata=data[:]
    for j in range(m):
        if stds[j] > 0:
           rdata[:,j]= (rdata[:,j]-means[j])/stds[j]
    return rdata
    data=np.array(data)
    # scales column data
    (n,m) = np.shape(data)
    rdata=data[:]
    for j in range(m):
        rdata[:,j]= means[j] + rdata[:,j]*stds[j]
    return rdata
# rdata = wd.xscale(data,means,stds)


def rescale(data: List[Vector]) -> List[Vector]:
    # rescales column data to zero mean and unit deviation
    data=np.array(data)
    (n,m) = np.shape(data)
    (means, stds) = scale(data)
    rdata=data[:]
    for j in range(m):
        if stds[j] > 0:
           rdata[:,j]= (rdata[:,j]-means[j])/stds[j]
    return rdata
# rdata = wd.rescale(data)

meanx, stdevx = scale(rescale(vectors))
assert np.all(meanx == [0, 0, 1])
assert np.all(stdevx == [1, 1, 0])
assert np.all(rescale(vectors) == xscale(vectors,means,stdevs))


def unscale(data: List[Vector],
            means:List[Vector],
            stds:List[Vector]) -> List[Vector]:
    data=np.array(data)
    # unscales column data
    (n,m) = np.shape(data)
    udata=data[:]
    for j in range(m):
        udata[:,j]= means[j] + data[:,j]*stds[j]
    return udata
# udata = wd.unscale(data,means,stds)

means, stdevs = scale(vectors)
assert np.all(vectors==unscale(rescale(vectors),means,stdevs))

# ---------- data splitting functionality using random
import random

def split_data(data: List[Vector], prob: float) -> Tuple[List[Vector], List[Vector]]:
    # split data into fractions [prob, 1 - prob]
    random.seed=20062000
    data = data[:]                    # Make a shallow copy
    random.shuffle(data)              # because shuffle modifies the list.
    cut = int(len(data) * prob)       # Use prob to find a cutoff
    return data[:cut], data[cut:]     # and split the shuffled list there.
# (train, test) = wd.split_data(data, p)

def train_test_split(xs: List[Vector],
                     ys: List[Vector],
                     test_pct: float) -> Tuple[List[Vector], List[Vector], List[Vector], List[Vector]]:
    # Generate the indices and split
    idxs = [i for i in range(len(xs))]
    train_idxs, test_idxs = split_data(idxs, 1 - test_pct)
    return ([xs[i] for i in train_idxs],  # x_train
            [xs[i] for i in test_idxs],   # x_test
            [ys[i] for i in train_idxs],  # y_train
            [ys[i] for i in test_idxs])   # y_test
# (x_train, x_test, y_train, y_test) = wd.train_test_split(xs, ys, 0.25)

def accuracy(tp: int, fp: int, fn: int, tn: int) -> float:
    correct = tp + tn
    total = tp + fp + fn + tn
    return correct / total

assert accuracy(70, 4930, 13930, 981070) == 0.98114

def precision(tp: int, fp: int, fn: int, tn: int) -> float:
    return tp / (tp + fp)

assert precision(70, 4930, 13930, 981070) == 0.014

def recall(tp: int, fp: int, fn: int, tn: int) -> float:
    return tp / (tp + fn)

assert recall(70, 4930, 13930, 981070) == 0.005

def f1_score(tp: int, fp: int, fn: int, tn: int) -> float:
    p = precision(tp, fp, fn, tn)
    r = recall(tp, fp, fn, tn)
    return 2 * p * r / (p + r)

assert f1_score(70, 4930, 13930, 981070) == 0.00736842105263158

# end of data processing functionality
